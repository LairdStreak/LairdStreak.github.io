from app import app

def main():
    app.main(cb)
    
def cb(token):
    print(token)

if __name__ == '__main__':
    main()